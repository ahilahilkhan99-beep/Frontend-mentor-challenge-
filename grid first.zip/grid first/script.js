const menuBtn = document.querySelector(".hamburger");

const closeBtn = document.querySelector(".close-menu");

const burgerMenu = document.querySelector(".Hamburger-menu");

const card = document.querySelectorAll(".card");

const hero =document.querySelector(".hero");

const footer = document.querySelector("footer");



menuBtn.addEventListener("click", function () {
    burgerMenu.style.display = "flex";
    menuBtn.style.display = "none";
    closeBtn.style.display = "flex";
    card.forEach(function (card) {
        card.style.backgroundColor = "#254cde";
    });
    hero.style.backgroundColor = "#254cde";
    footer.style.backgroundColor = "#254cde";
});

closeBtn.addEventListener("click", function () {
    burgerMenu.style.display = "none";
    menuBtn.style.display = "flex";
    closeBtn.style.display = "none";
    card.forEach(function (card) {
        card.style.backgroundColor = "#2854FD";
    });
    hero.style.backgroundColor = "#2854FD";
    footer.style.backgroundColor = "#2854FD";
});
